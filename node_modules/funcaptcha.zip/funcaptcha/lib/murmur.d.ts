declare var x64hash128: (t: any, r: any) => string;
export default x64hash128;
